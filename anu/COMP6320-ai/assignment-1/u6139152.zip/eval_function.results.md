# Question 6: Evaluation Functions for Two-Player Games

| **Maze**                 | **Depth** | **Score** |
| ------------------------ | :-------: | :-------: |
| `testAdversial`          |    12     |    255    |
| ` smallAdversarial`      |     2     |    92     |
| ` aiAdversarial`         |    10     |    83     |
| ` anuAdversarial`        |     8     |    168    |
| ` mazeAdversarial`       |    10     |    -86    |
| ` smallDenseAdversarial` |     6     |    344    |
| `aiDenseAdversarial`     |     6     |   -403    |
| ` anuDenseAdversarial`   |     6     |   -118    |
| ` mazeDenseAdversarial`  |     6     |   -134    |

